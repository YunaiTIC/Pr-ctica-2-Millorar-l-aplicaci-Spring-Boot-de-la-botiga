package com.example.botiga;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BotigaApplicationTests {

	@Test
	void contextLoads() {
	}

}
