package com.accesadades.botiga.Service;

import com.accesadades.botiga.Model.Subcategory;
import java.util.Set;

public interface SubcategoryService {
    // Retorna totes les subcategories
    Set<Subcategory> findAllSubcategories();
      // Elimina una subcategoria pel seu identificador
    Set<Subcategory> findSubcategoriesByCategoryId(Long categoryId);
}
