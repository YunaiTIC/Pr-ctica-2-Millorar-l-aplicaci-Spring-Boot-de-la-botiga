package com.accesadades.botiga.Service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.accesadades.botiga.Model.Subcategory;
import com.accesadades.botiga.Repositori.SubcategoryRepository;
import com.accesadades.botiga.Service.SubcategoryService;

import java.util.Set;
import java.util.HashSet;

@Service
public class SubcategoryServiceImpl implements SubcategoryService {

    @Autowired
    private SubcategoryRepository subcategoryRepository;

    // Retorna totes les subcategories
    @Override
    public Set<Subcategory> findAllSubcategories() {
        return new HashSet<>(subcategoryRepository.findAll());
    }


      // Cerca una subcategoria pel seu nom
    @Override
    public Set<Subcategory> findSubcategoriesByCategoryId(Long categoryId) {
        return subcategoryRepository.findByCategoryId(categoryId);
    }
}
