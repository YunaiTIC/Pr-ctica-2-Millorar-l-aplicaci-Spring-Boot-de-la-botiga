package com.accesadades.botiga.Repositori;

import org.springframework.stereotype.Repository;
import com.accesadades.botiga.Model.Subcategory;
import org.springframework.data.repository.CrudRepository;
import org.springframework.lang.NonNull;
import java.util.Set;

@Repository
public interface SubcategoryRepository extends CrudRepository<Subcategory, Long> {
    @Override
    @NonNull
    Set<Subcategory> findAll();

    Subcategory findByName(String name);

    Set<Subcategory> findByCategoryId(Long categoryId);
}
