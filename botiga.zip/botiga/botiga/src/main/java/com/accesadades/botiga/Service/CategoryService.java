package com.accesadades.botiga.Service;

import java.util.Set;
import com.accesadades.botiga.Model.Category;

// Interfície per a serveis de categoria

public interface CategoryService {
    Set<Category> findAllCategories();
      // Cerca una categoria pel seu nom
    Category findCategoryByName(String name);
     // Desa una nova categoria o actualitza una existent
    Category saveCategory(Category category);
    void deleteCategory(Long categoryId);
}
