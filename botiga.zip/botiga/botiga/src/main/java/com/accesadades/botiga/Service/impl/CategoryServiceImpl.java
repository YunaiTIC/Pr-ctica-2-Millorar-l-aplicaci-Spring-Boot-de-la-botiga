package com.accesadades.botiga.Service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.accesadades.botiga.Model.Category;
import com.accesadades.botiga.Repositori.CategoryRepository;
import com.accesadades.botiga.Service.CategoryService;

import java.util.Set;

@Service
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    // Retorna totes les categories
    @Override
    public Set<Category> findAllCategories() {
        return categoryRepository.findAll();
    }

    // Cerca una categoria pel seu nom
    @Override
    public Category findCategoryByName(String name) {
        return categoryRepository.findByName(name);
    }

    // Desa una nova categoria o actualitza una existent
    @Override
    public Category saveCategory(Category category) {
        return categoryRepository.save(category);
    }

    // Elimina una categoria pel seu identificador
    @Override
    public void deleteCategory(Long categoryId) {
        categoryRepository.deleteById(categoryId);
    }
}
