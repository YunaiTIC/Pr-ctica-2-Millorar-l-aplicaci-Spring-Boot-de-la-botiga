package com.accesadades.botiga.Service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.accesadades.botiga.Model.Product;
import com.accesadades.botiga.Repositori.ProductRepository;
import com.accesadades.botiga.Service.ProductService;

import java.util.Set;

@Service
public class ProductServiceImpl implements ProductService {

@Autowired
private ProductRepository productRepository;

@Override
public Set<Product> findAllProducts() {
    return productRepository.findAll();
}
// Cerca un producte pel seu nom
@Override
public Product findProductsByName(String name) {
    return productRepository.findByName(name);
}

@Override
public Set<Product> findAllProducts(String subcategory) {
    //
    return null;
}

@Override
public void increasePrice(Product product) {
    //
}

 // Desa un nou producte o actualitza un existent

@Override
public void saveProduct(Product product) {
    productRepository.save(product);
}


 // Elimina un producte pel seu identificador
@Override
public void deleteProduct(Long productId) {
    productRepository.deleteById(productId);
}



}