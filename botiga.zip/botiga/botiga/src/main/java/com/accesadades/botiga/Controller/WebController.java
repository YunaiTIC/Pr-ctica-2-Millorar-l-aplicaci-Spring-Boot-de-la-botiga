package com.accesadades.botiga.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.accesadades.botiga.Model.Product;
import com.accesadades.botiga.Service.ProductService;
import com.accesadades.botiga.Service.CategoryService;
import com.accesadades.botiga.Service.SubcategoryService;

import java.util.Set;

@Controller
@RequestMapping("/")
public class WebController {

    @Autowired
    private ProductService productService;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private SubcategoryService subcategoryService;

    // Mostra la pàgina d'inici
    @RequestMapping("/")
    public String index(Model model) {
        return "index";
    }

    // Mostra el catàleg de productes
    @RequestMapping("/catalog")
    public String catalog(Model model) {
        Set<Product> products = productService.findAllProducts();
        model.addAttribute("products", products);
        return "catalog";
    }

    // Cerca productes pel nom
    @GetMapping({"/search", "/prodname"})
    public String searchProductByName(@RequestParam(value = "name", required = false) String name, Model model) {
        if (name != null) {
            Product product = productService.findProductsByName(name);
            model.addAttribute("product", product);
        }
        return "search";
    }

    // Mostra el formulari de creació de producte
    @GetMapping("/createProduct")
    public String createProductForm(Model model) {
        model.addAttribute("product", new Product());
        model.addAttribute("categories", categoryService.findAllCategories());
        model.addAttribute("subcategories", subcategoryService.findAllSubcategories());
        return "product_form";
    }

    // Processa el formulari de creació de producte
    @PostMapping("/createProduct")
    public String createProduct(@ModelAttribute Product product) {
        productService.saveProduct(product);
        return "redirect:/catalog";
    }

    // Mostra el formulari de nou producte
    @GetMapping("/products/new")
    public String showNewProductForm(Model model) {
        model.addAttribute("product", new Product());
        model.addAttribute("categories", categoryService.findAllCategories());
        model.addAttribute("subcategories", subcategoryService.findAllSubcategories());
        return "product_form";
    }

    // Desa el nou producte
    @PostMapping("/products/saveProduct")
    public String saveProduct(@ModelAttribute("product") Product product) {
        productService.saveProduct(product);
        return "redirect:/products/new";
    }
}
