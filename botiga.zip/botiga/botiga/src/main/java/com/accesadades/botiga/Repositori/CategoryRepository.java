package com.accesadades.botiga.Repositori;

import org.springframework.stereotype.Repository;
import com.accesadades.botiga.Model.Category;
import org.springframework.data.repository.CrudRepository;
import org.springframework.lang.NonNull;
import java.util.Set;

@Repository
public interface CategoryRepository extends CrudRepository<Category, Long> {
    @Override
    @NonNull
    Set<Category> findAll();

    Category findByName(String name);
}
